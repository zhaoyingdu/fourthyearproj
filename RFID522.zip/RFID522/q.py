
import RPi.GPIO as GPIO
import MFRC522
import signal
import time
from threading import*
from Tkinter import StringVar
from Tkinter import*
import Tkinter as tk
import threading
    
continue_reading = True

temp=0

flag=True
root =Tk()
root.title('CountDown')
root['width'] = 400
root['height'] = 300
var = tk.StringVar()    

var.set('OMG! This is TK!')
l = tk.Label(root,
    textvariable=var, font=('Arial', 12), width=15, height=2)
l.pack()

# Capture SIGINT for cleanup when the script is aborted
def end_read(signal,frame):
    global continue_reading
    print ("Ctrl+C captured, ending read.")
    continue_reading = False
    GPIO.cleanup()

# Hook the SIGINT
signal.signal(signal.SIGINT, end_read)

# Create an object of the class MFRC522
MIFAREReader = MFRC522.MFRC522()

# Welcome message
print ("Welcome")
stat='3'
def timer():

    global flag
    global var
    for k in range(5):
        var.set('remain' + str(k) + 's')
        time.sleep(1)
        if k==3:
            flag=False
       


# This loop keeps checking for chips. If one is near it will get the UID and authenticate
class a(Thread):

    def run(self):
        while continue_reading:
            t1 = threading.Thread(target=timer)

            # Scan for cards
            (status,TagType) = MIFAREReader.MFRC522_Request(MIFAREReader.PICC_REQIDL)

            # If a card is found
            if status == MIFAREReader.MI_OK:
                print("Card detected")

            # Get the UID of the card
            (status,uid) = MIFAREReader.MFRC522_Anticoll()

            # If we have the UID, continue
            if status == MIFAREReader.MI_OK:
                # Print UID
                print str(uid[0])+str(uid[1])+str(uid[2])+str(uid[3])
                time.sleep(1)

                if stat=='2':

                    #root=Tk()
                    #theLabel=Label(root, text="You are in the queue and time is")
                    #theLabel.pack()
                    #root.mainloop()
                    print('1')

                if stat=='3':
                    global var
                    temp = uid
                    while flag:
                        if not t1.isAlive():
                                t1.start()
                        # Scan for cards
                        (status, TagType) = MIFAREReader.MFRC522_Request(MIFAREReader.PICC_REQIDL)

                        # If a card is found
                        if status == MIFAREReader.MI_OK:
                            print("Card detected")

                        # Get the UID of the card
                        (status, uid) = MIFAREReader.MFRC522_Anticoll()

                        # If we have the UID, continue
                        if status == MIFAREReader.MI_OK:
                            if uid == temp:
                                print "yes"
                                break
                    var.set('GG')    

            flag=True
            
t2=a()
t2.start()
root.mainloop()

