

import RPi.GPIO as GPIO
import MFRC522
import signal
import time
import datetime
import threading
import requests
import json

continue_reading = True
class JSONObject:
    def __init__(self,d):
        self.__dict__=d
# Capture SIGINT for cleanup when the script is aborted
def end_read(signal,frame):
    global continue_reading
    print "Ctrl+C captured, ending read."
    continue_reading = False
    GPIO.cleanup()

# Hook the SIGINT
signal.signal(signal.SIGINT, end_read)

# Create an object of the class MFRC522
MIFAREReader = MFRC522.MFRC522()

# Welcome message
print "Please Tap your card!"


# This loop keeps checking for chips. If one is near it will get the UID and authenticate
while continue_reading:
    
    # Scan for cards    
    (status,TagType) = MIFAREReader.MFRC522_Request(MIFAREReader.PICC_REQIDL)

    # If a card is found
    if status == MIFAREReader.MI_OK:
        now=datetime.datetime.now()
        print "You are parking in Secion A at"
        print now.strftime("%H:%M")
	url='http://192.168.123.71:12341/checkItem/'+str(uid[0])+str(uid[1])+str(uid[2])+str(uid[3])
	print url
	r=requests.get(url)
	print r.content
	result = json.loads(r.content,object_hook=JSONObject)        
    # Get the UID of the card
    (status,uid) = MIFAREReader.MFRC522_Anticoll()

    # If we have the UID, continue
    if status == MIFAREReader.MI_OK:

        # Print UID
       # print  str(uid[0])+str(uid[1])+str(uid[2])+str(uid[3])
    
      
    
        time.sleep(3)
