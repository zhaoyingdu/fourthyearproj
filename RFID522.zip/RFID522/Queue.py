
import RPi.GPIO as GPIO
import MFRC522
import signal
import time
from threading import*
from Tkinter import*
import Tkinter as tk
import threading
import requests
import json
    
continue_reading = True

temp=0

flag=True

stopCountdown=False
root=Tk()
root.title('window')
root.geometry('300x200')
var = tk.StringVar()
l=tk.Label(root,textvariable=var,font=('Arial',10),width=30,height=2)
l.pack()

class JSONObject:
    def __init__(self,d):
        self.__dict__=d


#Capture SIGINT for cleanup when the script is aborted
def end_read(signal,frame):
    global continue_reading
    print ("Ctrl+C captured, ending read.")
    continue_reading = False
    GPIO.cleanup()

# Hook the SIGINT
signal.signal(signal.SIGINT, end_read)

# Create an object of the class MFRC522
MIFAREReader = MFRC522.MFRC522()


# Welcome message
print ("Welcome")
def timer():
    print("Started")
    global flag
    global var
    global stopCountdown
    for i in range(0,8):
        if stopCountdown:
            break
        var.set("tap again: "+str(8-i))
        time.sleep(1)
    flag=False

def tap():
    global flag
    global MIFAREReader
    global var
    global stopCountdown


    while continue_reading:
        stopCountdown = False
        t1 = threading.Thread(target=timer)
		
	var.set("tap to queue")

	# Scan for cards    
	(status,TagType) = MIFAREReader.MFRC522_Request(MIFAREReader.PICC_REQIDL)

	# If a card is found
	if status == MIFAREReader.MI_OK:
	    print("Card detected")
		
	# Get the UID of the card
	(status,uid) = MIFAREReader.MFRC522_Anticoll()

	# If we have the UID, continue
	if status == MIFAREReader.MI_OK:
	    # Print UID
	    print str(uid[0])+str(uid[1])+str(uid[2])+str(uid[3])
	    time.sleep(1)
	    url='http://192.168.123.71:12341/checkItem/'+str(uid[0])+str(uid[1])+str(uid[2])+str(uid[3])
	    print url
	    r=requests.get(url)
	    print r.content
	    result = json.loads(r.content,object_hook=JSONObject)
	    print str(result.status)
	    

	    if result.status==2:

	        print("already in the line, time: "+str(result.time))
			   
	    if result.status==3:
                print("joined")
		temp = uid
		while flag:
		    if not t1.isAlive():
			t1.start()
			print("threaded created")
		    # Scan for cards
		    (status, TagType) = MIFAREReader.MFRC522_Request(MIFAREReader.PICC_REQIDL)

		    # If a card is found
		    if status == MIFAREReader.MI_OK:
			print("Card detected")

		    # Get the UID of the card
		    (status, uid) = MIFAREReader.MFRC522_Anticoll()

		    # If we have the UID, continue
		    if status == MIFAREReader.MI_OK:
		        if uid == temp:
			    print "yes"
			    url="http://192.168.123.71:12341/changeItem/"+str(uid[0])+str(uid[1])+str(uid[2])+str(uid[3])
			    r=requests.get(url)
	                    print r.content
			    stopCountdown = True
			    time.sleep(1)
			    var.set("change line successed")
			    time.sleep(2)
			    break
        flag=True
		
		
t2 = threading.Thread(target=tap)
t2.start()
root.mainloop()
