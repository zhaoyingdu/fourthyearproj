
import RPi.GPIO as GPIO
import MFRC522
import signal
import time
from threading import*
import threading
    
continue_reading = True

temp=0

flag=True

stopCountdown=False

#Capture SIGINT for cleanup when the script is aborted
def end_read(signal,frame):
    global continue_reading
    print ("Ctrl+C captured, ending read.")
    continue_reading = False
    GPIO.cleanup()

# Hook the SIGINT
signal.signal(signal.SIGINT, end_read)

# Create an object of the class MFRC522
MIFAREReader = MFRC522.MFRC522()


# Welcome message
print ("Welcome")
print("tap to queue")
stat='3'
def timer():
    print("t1 kai shi yun xing")
    global flag
    global var
    global stopCountdown
    for i in range(0,3):
        if stopCountdown:
            break
        print("u r in other queue, tap again to join this queue. countdown: "+str(3-i))
        time.sleep(1)
    print("tap to queue")
    flag=False

def shuaka():
    global flag
    global MIFAREReader
    global var
    global stopCountdown


    while continue_reading:
        stopCountdown = False
        t1 = threading.Thread(target=timer)
		
	#print("tap to queue")

	# Scan for cards    
	(status,TagType) = MIFAREReader.MFRC522_Request(MIFAREReader.PICC_REQIDL)

	# If a card is found
	if status == MIFAREReader.MI_OK:
	    print("Card detected")
		
	# Get the UID of the card
	(status,uid) = MIFAREReader.MFRC522_Anticoll()

	# If we have the UID, continue
	if status == MIFAREReader.MI_OK:
	    # Print UID
	    print str(uid[0])+str(uid[1])+str(uid[2])+str(uid[3])
	    time.sleep(1)

	    if stat=='2':

	        root=Tk()
		theLabel=Label(root, text="You are in the queue and time is")
		theLabel.pack()
		root.mainloop()
			   
	    if stat=='3':
                print("jin ru fen zhi")
		temp = uid
		while flag:
		    if not t1.isAlive():
			t1.start()
			print("yun xing t1")
		    # Scan for cards
		    (status, TagType) = MIFAREReader.MFRC522_Request(MIFAREReader.PICC_REQIDL)

		    # If a card is found
		    if status == MIFAREReader.MI_OK:
			print("Card detected")

		    # Get the UID of the card
		    (status, uid) = MIFAREReader.MFRC522_Anticoll()

		    # If we have the UID, continue
		    if status == MIFAREReader.MI_OK:
		        if uid == temp:
			    print "yes"
			    pass
			    stopCountdown = True
			    time.sleep(1)
			    print("change line successed")
			    print("tap to queue")
			    time.sleep(2)
			    break
        flag=True
		
		
t2 = threading.Thread(target=shuaka)
t2.start()
